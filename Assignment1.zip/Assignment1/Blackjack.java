import java.util.*;

public class Blackjack
{
	public static void main(String [] args)
	{
		int decks = Integer.parseInt(args[1]);
		int rounds = Integer.parseInt(args[0]);
		int playerWins = 0, dealerWins = 0, pushes = 0, roundsPlayed = 0;
		int pValue=0, dValue=0; 
		boolean trace = false;
		RandIndexQueue<Card> shoe = new RandIndexQueue<Card>(decks*52);
		RandIndexQueue<Card> player = new RandIndexQueue<Card>(20);
		RandIndexQueue<Card> dealer = new RandIndexQueue<Card>(20);
		RandIndexQueue<Card> discard = new RandIndexQueue<Card>(decks*26);
		
		System.out.println("Starting Blackjack with " + rounds+ " rounds and " + decks+" decks in the shoe");
		if(rounds<=10)
		{
			trace = true;
		}
		
		for(int i=0;i<decks;i++)
		{
			for(Card.Suits s: Card.Suits.values())
			{
				for(Card.Ranks r: Card.Ranks.values())
				{
					shoe.offer(new Card(s,r));
				}
			}
		}

		
		while(roundsPlayed < rounds)
		{
			if(trace)
			{
				System.out.println("\nRound " + (roundsPlayed) + " beginning");
			}
			for(int i=0;i<2;i++)
			{
				player.offer(shoe.poll());
				dealer.offer(shoe.poll());
			}
			pValue = getFirstHand(player);
			dValue = getFirstHand(dealer);
			if(trace)
			{
				System.out.println("Player: " + player.toString() + " : " + pValue);
				System.out.println("Dealer: " + dealer.toString() + " : " + dValue);
			}
			
			if(pValue == 21 && dValue != 21)
			{
				playerWins++;
				if(trace)
				{
					System.out.println("Result: Player Wins!");
				}
			}
			else if(pValue != 21 && dValue == 21)
			{
				dealerWins++;
				if(trace)
				{
					System.out.println("Result: Dealer Wins!");
				}
			}
			else if(pValue == 21 && dValue == 21)
			{
				pushes++;
				if(trace)
				{
					System.out.println("Result: Push!");
				}
			}
			else if(pValue != 21 && dValue != 21)
			{
				
				while(pValue<17)
				{
					player.offer(shoe.poll()); 
					pValue = getValue(player);
					if(trace)
					{
						System.out.println("Player HITS: " + player.get(player.size()-1).toString());
					}
				}
				if(pValue>21)
				{
					dealerWins++;
					if(trace)
					{
						System.out.println("Player BUSTS: " + player.toString() + " : " + pValue);
						System.out.println("Result: Dealer Wins!");
					}
				}
				else
				{
					if(trace)
					{
						System.out.println("Player STANDS: "+ player.toString() + " : " + pValue);
					}
					while(dValue<17)
					{
						dealer.offer(shoe.poll()); 
						dValue = getValue(dealer);
						if(trace)
						{
							System.out.println("Dealer HITS: " + dealer.get(dealer.size()-1).toString());
						}
					}
					if(dValue>21)
					{
						playerWins++;
						if(trace)
						{
							System.out.println("Dealer BUSTS: " + dealer.toString() + " : " + dValue);
							System.out.println("Result: Player Wins!");
						}
					}
					else
					{
						if(trace)
						{
							System.out.println("Dealer STANDS: " + dealer.toString() + " : " + dValue);
						}
					}
				}

				if((pValue == 21 && dValue < 21) || ((pValue > dValue) && pValue<21 && dValue<21))
				{
					playerWins++;
					if(trace)
					{
						System.out.println("Result: Player Wins!");
					}
				}
				else if((pValue < 21 && dValue == 21) || ((pValue < dValue) && pValue<21 && dValue<21))
				{
					dealerWins++;
					if(trace)
					{
						System.out.println("Result: Dealer Wins!");
					}
				}
				else if(pValue == dValue)
				{
					pushes++;
					if(trace)
					{
						System.out.println("Result: Push!");
					}
				}
			}
			
			while(!player.isEmpty())
			{
				discard.offer(player.poll()); 
			}
			while(!dealer.isEmpty())
			{
				discard.offer(dealer.poll()); 
			}
			
			if(shoe.size()<=.25*decks*52)
			{
				while(!discard.isEmpty())
				{
					shoe.offer(discard.poll()); 
					System.out.println("It is round " + roundsPlayed+1 +". The shoe is being reset.");
				}
				shoe.shuffle(); 
			}
			roundsPlayed++;
		}
		System.out.println("\nAfter "+ roundsPlayed+" rounds, here are the results: ");
		System.out.println("Player wins: "+playerWins);
		System.out.println("Dealer wins: "+dealerWins);
		System.out.println("Pushes: "+pushes);
	}
	
	public static int getValue(RandIndexQueue<Card> hand)
	{
		int size = hand.size();
		int total = 0, count = 0, aces = 0;
		for(int i=0;i<size;i++)
		{
			if(hand.get(i).value()!= 11)
			{
				total += hand.get(i).value(); 
				count++;
			}
		}
		
		aces = size - count; 
		if(aces == 0)
		{
			return total;
		}
		else if((total + 11 + aces - 1) == 21)
		{
			return (total + 11 + aces - 1);
		}
		else if((total + aces) == 21)
		{
			return (total + aces);
		}
		else if((total + 11 + aces - 1) < 17)
		{
			return (total + 11 + aces - 1);
		}
		else
		{
			return(total + aces);
		}
	}	
	
	public static int getFirstHand(RandIndexQueue<Card> hand)
	{
		if(hand.get(0).value() + hand.get(1).value() > 21)
		{
			return (hand.get(0).value() + hand.get(1).value() - 10);
		}
		else
		{
			return (hand.get(0).value() + hand.get(1).value());
		}
	}
}