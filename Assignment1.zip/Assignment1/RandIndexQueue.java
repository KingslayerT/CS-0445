import java.util.*;

public class RandIndexQueue<T> implements MyQ<T>, Indexable<T>, Shufflable
{
	private T[] data;
	private int moves, items;
	private int count = 0;
	
	public RandIndexQueue(int size)
	{
		items = size;
		@SuppressWarnings("unchecked")
		T[] dat=(T[]) new Object[items];
		data = dat;
		
	}
	// Add a new Object to the MyQ in the next available location.  If
	// all goes well, return true; otherwise return false.
	public boolean offer(T item)
	{
		if (count<data.length-1)
		{
			data[count] = item;
			count++;
			moves++;
			return true;
		}
		else if(count==data.length-1)
		{
			@SuppressWarnings("unchecked")
			T[] newData = (T[]) new Object[data.length*2];
			for(int i=0;i<data.length-1;i++)
			{
				newData[i]=data[i];
			}
			data=newData;
			data[count] = item;
			count++;
			moves++;
			return true;
			
		}
		else
			return false;
	}
	
	// Remove and return the logical front item in the MyQ.  If the MyQ
	// is empty, return null
	public T poll()
	{
		if(count==0)
			return null;
		else
		{
			T temp = data[0];
			count--;
			for (int i=0; i<count; i++)
			{
				data[i] = data[i+1];
			}
			data[count] = null;
			return temp;
		}
	}
	
	// Get and return the logical front item in the MyQ without removing it.
	// If the MyQ is empty, return null
	public T peek()
	{
		if(count==0)
			return null;
		else
		{
			return data[count-1];
		}
	}
	
	// Return true if the MyQ is full, and false otherwise
	public boolean isFull()
	{
		if (count == data.length)
			return true;
		else
			return false;
	}
	
	// Return true if the MyQ is empty, and false otherwise
	public boolean isEmpty()
	{
		if(count==0)
			return true;
		else
			return false;
	}
	// Return the number of items currently in the MyQ.  Determining the
	// length of a queue can sometimes very useful.
	public int size()
	{
		return count;
	}

	// Reset the MyQ to empty status by reinitializing the variables
	// appropriately
	public void clear()
	{
		for(int i=0; i<data.length-1; i++)
		{
			data[i] = null;
		}
		count=0;
	}
	
	// Methods to get and set the value for the moves variable.  The idea for
	// this is the same as shown in Recitation Exercise 1 -- but now instead
	// of a separate interface these are incorporated into the MyQ<T>
	// interface.  The value of your moves variable should be updated during
	// an offer() or poll() method call.  However, any data movement required
	// to resize the underlying array should not be counted in the moves.
	public int getMoves()
	{
		return this.moves;
	}
	public void setMoves(int moves)
	{
		this.moves=moves;
	}
	
	// Get and return the value located at logical location i in the implementing
	// collection, where location 0 is the logical beginning of the collection.
	// If the collection has fewer than (i+1) items, throw an IndexOutOfBoundsException 
	public T get(int i)
	{
		if (i >= items)
		{
			System.out.println("IndexOutOfBoundsException");
			return null;
		}
		else
			return data[i];
	}
	
	// Assign item to logical location i in the implementing collection, where location
	// 0 is the logical beginning of the collection.  If the collection has fewer than
	// (i+1) items, throw an IndexOutOfBoundsException
	public void set(int i, T item)
	{
		if (i >= items)
		{
			System.out.println("IndexOutOfBoundsException");
		}
		else
		{
			if (i >= count)
			{
				data[i] = item;
				count++;
			}
			else
				data[i] = item;
		}
	}
	
	// Return the number of items currently in the Indexable. Note that this is the
	// same method specified in the MyQ<T> interface.  It is fine for a single method
	// to be part of more than one interface
	
	
	public void shuffle()
	{
		Random rand = new Random();
		int index;
		T temp;
		for(int i=0;i<count;i++)
		{
			index = rand.nextInt(count);
			temp = data[i];
			data[i] = data[index];
			data[index] = temp;
		}
	}
	public String toString()
	{
		StringBuilder b = new StringBuilder("Contents: ");
		for (int i = 0; i < count; i++)
		{
			b.append(data[i] + " ");
		}
		return b.toString();
	}
	// Reorganize the items in the object in a pseudo-random way.  The exact
	// way is up to you but it should utilize a Random object (see Random in 
	// the Java API).  Note that this should not change the size of the
	// collection.
}