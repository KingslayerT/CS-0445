import java.util.*;
import java.io.*;

public class Assig2B
{
	public static void main(String [] args)throws Exception
	{
		//StringBuilder
		BufferedReader reader = new BufferedReader(new FileReader(args[0]));
		StringBuilder builder = new StringBuilder();
		int count = 0;
		int bb;
		while((bb = reader.read())!=-1)
			count++;
		long startTime = System.nanoTime();
		while((bb = reader.read())!=-1)
			builder.append((char)bb);
		long endTime = System.nanoTime();
		long usingTime = endTime-startTime;
		long averageTime = usingTime/count;
		System.out.println("!!!Test StringBuilder!!!");
		System.out.println();
		System.out.println("Using time for method append: " + usingTime + " nanoseconds");
		System.out.println("Average time for method append: " + averageTime+ " nanoseconds");
		System.out.println();
		
		startTime = System.nanoTime();
		while(builder.length()>0)
			builder.delete(0,1);
		endTime = System.nanoTime();
		usingTime = endTime-startTime;
		averageTime = usingTime/count;
		System.out.println("Using time for method delete: " + usingTime + " nanoseconds");
		System.out.println("Average time for method delete: " + averageTime+ " nanoseconds");
		System.out.println();
		
		int loc = 0;
		startTime = System.nanoTime();
		while((bb = reader.read())!=-1)
		{
			loc = builder.length()/2;
			builder.insert(loc, (char)bb);
		}
		endTime = System.nanoTime();
		usingTime = endTime-startTime;
		averageTime = usingTime/count;
		System.out.println("Using time for method insert: " + usingTime + " nanoseconds");
		System.out.println("Average time for method insert: " + averageTime+ " nanoseconds");
		System.out.println();
		
		
		//MyStringBuilder
		BufferedReader aa = new BufferedReader(new FileReader(args[0]));
		MyStringBuilder cc = new MyStringBuilder();
		startTime = System.nanoTime();
		while((bb = aa.read())!=-1)
			cc.append((char)bb);
		endTime = System.nanoTime();
		usingTime = endTime-startTime;
		averageTime = usingTime/count;
		System.out.println("!!!Test MyStringBuilder!!!");
		System.out.println();
		System.out.println("Using time for method append: " + usingTime + " nanoseconds");
		System.out.println("Average time for method append: " + averageTime+ " nanoseconds");
		System.out.println();
		
		startTime = System.nanoTime();
		while(cc.length()>0)
			cc.delete(0,1);
		endTime = System.nanoTime();
		usingTime = endTime-startTime;
		averageTime = usingTime/count;
		System.out.println("Using time for method delete: " + usingTime + " nanoseconds");
		System.out.println("Average time for method delete: " + averageTime+ " nanoseconds");
		System.out.println();
		
		loc = 0;
		startTime = System.nanoTime();
		while((bb = aa.read())!=-1)
		{
			loc = cc.length()/2;
			cc.insert(loc, (char)bb);
		}
		endTime = System.nanoTime();
		usingTime = endTime-startTime;
		averageTime = usingTime/count;
		System.out.println("Using time for method insert: " + usingTime + " nanoseconds");
		System.out.println("Average time for method insert: " + averageTime+ " nanoseconds");
		System.out.println();
		

		
		
		//String
		BufferedReader reader1 = new BufferedReader(new FileReader(args[0]));
		String str = new String();
		startTime = System.nanoTime();
		while((bb = reader1.read())!=-1)
			str += (char)bb;
		endTime = System.nanoTime();
		usingTime = endTime-startTime;
		averageTime = usingTime/count;
		System.out.println("!!!Test String!!!");
		System.out.println();
		System.out.println("Using time for method append: " + usingTime + " nanoseconds");
		System.out.println("Average time for method append: " + averageTime+ " nanoseconds");
		System.out.println();
		
		startTime = System.nanoTime();
		for(int i=0; i<str.length();i++)
			str = str.substring(0, str.length());
		endTime = System.nanoTime();
		usingTime = endTime-startTime;
		averageTime = usingTime/count;
		System.out.println("Using time for method delete: " + usingTime + " nanoseconds");
		System.out.println("Average time for method delete: " + averageTime+ " nanoseconds");
		System.out.println();
		
		loc = 0;
		startTime = System.nanoTime();
		while((bb = reader1.read())!=-1)
		{
			loc = str.length()/2;
			String s1 = str.substring(0, loc);
			String s2 = str.substring(loc, str.length());
			str = s1 + (char)bb + s2;
		}
		endTime = System.nanoTime();
		usingTime = endTime-startTime;
		averageTime = usingTime/count;
		System.out.println("Using time for method insert: " + usingTime + " nanoseconds");
		System.out.println("Average time for method insert: " + averageTime+ " nanoseconds");
		System.out.println();
	}
}
		
		