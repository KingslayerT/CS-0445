// CS 0445 Spring 2018
// Read this class and its comments very carefully to make sure you implement
// the class properly.  The data and public methods in this class are identical
// to those MyStringBuilder, with the exception of the two additional methods
// shown at the end.  You cannot change the data or add any instance
// variables.  However, you may (and will need to) add some private methods.
// No iteration is allowed in this implementation. 

// For more details on the general functionality of most of these methods, 
// see the specifications of the similar method in the StringBuilder class.  
public class MyStringBuilder2
{
	// These are the only three instance variables you are allowed to have.
	// See details of CNode class below.  In other words, you MAY NOT add
	// any additional instance variables to this class.  However, you may
	// use any method variables that you need within individual methods.
	// But remember that you may NOT use any variables of any other
	// linked list class or of the predefined StringBuilder or 
	// or StringBuffer class in any place in your code.  You may only use the
	// String class where it is an argument or return type in a method.
	private CNode firstC;	// reference to front of list.  This reference is necessary
							// to keep track of the list
	private CNode lastC; 	// reference to last node of list.  This reference is
							// necessary to improve the efficiency of the append()
							// method
	private int length;  	// number of characters in the list

	// You may also add any additional private methods that you need to
	// help with your implementation of the public methods.

	// Create a new MyStringBuilder2 initialized with the chars in String s
	public MyStringBuilder2(String s)
	{
		if (s == null || s.length() == 0) 
		{					 			  
			firstC = null;
			lastC = null;
			length = 0;
		}
		else
			makeBuilder(s, 0);
	}
	
	private void makeBuilder( String s, int pos)
	{
		if(s != null && pos<s.length()-1)
		{
			makeBuilder(s, pos+1);
			firstC = new CNode(s.charAt(pos), firstC);
			length++;
		}
		else if( pos == s.length()-1)
		{
			firstC = new CNode( s.charAt(pos));
			lastC = firstC;
			length++;
		}
		else
		{
			firstC = null;
			lastC = null;
			length = 0;
		}
	}

	// Create a new MyStringBuilder2 initialized with the chars in array s
	public MyStringBuilder2(char [] s)
	{
		if (s == null || s.length == 0) 
		{					 			  
			firstC = null;
			lastC = null;
			length = 0;
		}
		else
			makeBuilder(s, 0);
	}
	
	private void makeBuilder( char[] s, int pos)
	{
		if(s != null && pos<s.length-1)
		{
			makeBuilder(s, pos+1);
			firstC = new CNode(s[pos], firstC);
			length++;
		}
		else if(pos==s.length-1)
		{
			firstC = new CNode(s[pos], firstC);
			lastC = firstC;
			length++;
		}
		else
		{
			firstC = null;
			lastC = null;
			length = 0;
		}
	}

	// Create a new empty MyStringBuilder2
	public MyStringBuilder2()
	{
		firstC = null;
		lastC = null;
		length = 0;
	}

	// Append MyStringBuilder2 b to the end of the current MyStringBuilder2, and
	// return the current MyStringBuilder2.  Be careful for special cases!
	public MyStringBuilder2 append(MyStringBuilder2 b)
	{
		if(b.length()==0 || b==null)
			return this;
		else
		{
			return stringAppend(b, b.firstC, 0);
		}
	}
	
	private MyStringBuilder2 stringAppend(MyStringBuilder2 b, CNode curr, int pos)
	{
		CNode temp = new CNode(curr.data);
		if(length>0 &&pos<b.length())
		{
			lastC.next = temp;
			lastC = temp;
			length ++;
			if(curr.next == null)
				return this;
			else
				return stringAppend(b, curr.next, pos+1);
		}
		else if(length==0)
		{
			firstC = temp;
			lastC = firstC;
			length++;
			return stringAppend(b, curr.next, pos+1);
		}
		else
			return this;
			
	}

	
	// Append String s to the end of the current MyStringBuilder2, and return
	// the current MyStringBuilder2.  Be careful for special cases!
	public MyStringBuilder2 append(String s)
	{
		if(s.length() == 0 || s == null)
			return this;
		else
		{
			return stringAppend(s,0);
		}
	}
	
	private MyStringBuilder2 stringAppend( String s, int pos)
	{
		CNode temp = new CNode(s.charAt(pos));
		if(length>0 && pos<s.length())
		{
			lastC.next = temp;
			lastC = temp;
			length++;
			if(pos==s.length()-1)
				return this;
			else
			{
				return stringAppend(s,pos+1);
			}
			
		}
		else if(length==0)
		{
			firstC = new CNode(s.charAt(pos));
			lastC = firstC;
			length++;
			return stringAppend(s,pos+1);
		}
		else
			return this;
	}

	// Append char array c to the end of the current MyStringBuilder2, and
	// return the current MyStringBuilder2.  Be careful for special cases!
	public MyStringBuilder2 append(char [] c)
	{
		if(c.length == 0 || c == null)
			return this;
		else
		{
			return stringAppend(c,0);
		}
	}
	
	private MyStringBuilder2 stringAppend(char[] c, int pos)
	{
		CNode temp = new CNode(c[pos]);
		if(length>0 && pos<c.length)
		{
			lastC.next = temp;
			lastC = temp;
			length++;
			if(pos==c.length-1)
				return this;
			else
			{
				return stringAppend(c,pos+1);
			}
			
		}
		else if(length==0)
		{
			firstC = new CNode(c[pos]);
			lastC = firstC;
			length++;
			return stringAppend(c,pos+1);
		}
		else
			return this;
	}

	// Append char c to the end of the current MyStringBuilder2, and
	// return the current MyStringBuilder2.  Be careful for special cases!
	public MyStringBuilder2 append(char c)
	{
		CNode temp = new CNode(c);
		if(length>0)
		{
			lastC.next = temp;
			lastC = temp;
			length++;
			return this;
		}
		else if(length==0)
		{
			firstC = temp;
			lastC = firstC;
			length++;
			return this;
		}
		else
			return this;
	}
	

	// Return the character at location "index" in the current MyStringBuilder2.
	// If index is invalid, throw an IndexOutOfBoundsException.
	public char charAt(int index)
	{
		char c = 0;
		if (index < length && index >= 0)
		{
			return findIndex(0, c, index, firstC);
		}
		else
		{
			throw new IndexOutOfBoundsException();
		}
	}
	
	private char findIndex( int pos, char c, int index, CNode curr)
	{
		if(pos==index)
		{
			c = curr.data;
			return c;
		}
		else
		{
			return findIndex(pos+1, c, index, curr.next);
		}
	}

	// Delete the characters from index "start" to index "end" - 1 in the
	// current MyStringBuilder2, and return the current MyStringBuilder2.
	// If "start" is invalid or "end" <= "start" do nothing (just return the
	// MyStringBuilder2 as is).  If "end" is past the end of the MyStringBuilder2, 
	// only remove up until the end of the MyStringBuilder2. Be careful for 
	// special cases!
	public MyStringBuilder2 delete(int start, int end)
	{
		if (start < 0 || start >= length || end <= start)
			return this;
		if (end > length)
			end = length;
		
		if(start == 0 && end == length)
		{
			length = 0;
			firstC = null;
			lastC = null;
			return this;
		}
		else
		{
			return stringDelete(start, end, 0, null, firstC, firstC.next, length);
		}
		
	}
	
	private MyStringBuilder2 stringDelete(int start, int end, int pos, CNode before, CNode curr, CNode after, int leng)
	{
		if(end >= leng)
		{ 
			if(pos == start-1)
			{
				lastC = curr;
				lastC.next = null;
				length = start;
				return this;
			} 
			else
			{
				return stringDelete(start, end, pos+1, before, after, after.next, leng);
			}
		}
		else if(pos < start)
		{ 
			return stringDelete(start, end, pos+1, curr, after, after.next, leng);
		} 
		else if(start == 0)
		{ 
			if(pos == end) 
				return this;

			firstC = firstC.next;
			length--;
			return stringDelete(start, end, pos+1, before, after, after.next, leng);
		} 
		else if(pos >= start && pos <= end && end != leng)
		{
			if(pos == end) 
				return this;

			before.next = after;
			length--;
			return stringDelete(start, end, pos+1, before, after, after.next, leng);
		} 
		else
		{ 
			return this;
		}
	}

	// Delete the character at location "index" from the current
	// MyStringBuilder2 and return the current MyStringBuilder2.  If "index" is
	// invalid, do nothing (just return the MyStringBuilder2 as is).
	// Be careful for special cases!
	public MyStringBuilder2 deleteCharAt(int index)
	{
		if (index < 0 || index >= length)
			return this;
		else
		{
			if(index==0)
			{
				firstC = firstC.next;
				length--;
				return this;
			}
			else
			{
				return stringDelete(index, 0, firstC, length);
			}
		}
	}
	
	private MyStringBuilder2 stringDelete(int index, int pos, CNode curr, int leng)
	{
		if(index==length-1 && pos ==length-3)
		{
			lastC = curr;
			lastC.next = null;
			length--;
			return this;
		}
		else
		{
			if(pos==index-1 )
			{
				curr.next = curr.next.next;
				return this;
			}
			else
			{
				stringDelete(index, pos+1, curr.next,leng);
				return this;
				
			}
		}
	}

	// Find and return the index within the current MyStringBuilder2 where
	// String str first matches a sequence of characters within the current
	// MyStringBuilder2.  If str does not match any sequence of characters
	// within the current MyStringBuilder2, return -1.  Think carefully about
	// what you need to do for this method before implementing it.
	public int indexOf(String str)
	{
		if(str == null) 
			return -1; 
		else 
			return findIndex(firstC, 0, str, 0, -1);
	}
	
	public int findIndex(CNode curr, int pos, String str, int matches, int startIndex)
	{
		if(matches == str.length()) 
			return startIndex;
		else if(pos == length && matches != str.length())
			return -1;
		else if(curr.data == str.charAt(matches))
		{ 
			if(matches == 0) 
				startIndex = pos;
			matches++;
			return findIndex(curr.next, pos+1, str, matches, startIndex);
		}
		else 
			return findIndex(curr.next, pos+1, str, 0, -1);
	}
	// Insert String str into the current MyStringBuilder2 starting at index
	// "offset" and return the current MyStringBuilder2.  if "offset" == 
	// length, this is the same as append.  If "offset" is invalid
	// do nothing.
	public MyStringBuilder2 insert(int offset, String str)
	{
		if(offset==length)
		{
			return append(str);
		}
		else if(offset<0 || offset>length)
			return this;
		else if(offset==0)
		{
			return stringInsert(0, str, offset, firstC, 0);
		}
		else
		{
			return stringInsert(0, str, offset, firstC, 0);
		}
	}
	
	private MyStringBuilder2 stringInsert(int pos, String str, int offset, CNode curr, int count)
	{
		
		if(offset==0 && count<str.length())
		{
			CNode temp;
			if(count == 0) 
				temp = new CNode(str.charAt(str.length()-1), firstC.next);
			else 
				temp = new CNode(str.charAt(str.length()-count-1), firstC.next);
			CNode temp1 = firstC;
			firstC = temp;
			firstC.next = temp1;
			return stringInsert(pos+1, str, offset, curr.next, count+1);	
		}
		else
		{
			if(pos >= offset-1 && pos < offset+str.length()-1)
			{
				CNode temp;
				if(count == 0) 
					temp = new CNode(str.charAt(count));
				else 
					temp = new CNode(str.charAt(count));

				temp.next = curr.next;
				curr.next = temp;

				return stringInsert(pos+1, str, offset, curr.next, count+1);
			} 
			else if(count == str.length())
			{
				length += str.length();
				return this;
			} 
			else
			{ 
				return stringInsert(pos+1, str, offset, curr.next, count);
			}
		}
	}

	// Insert character c into the current MyStringBuilder2 at index
	// "offset" and return the current MyStringBuilder2.  If "offset" ==
	// length, this is the same as append.  If "offset" is invalid, 
	// do nothing.
	public MyStringBuilder2 insert(int offset, char c)
	{
		if(offset<0 || offset>length)
			return this;
		else if(offset==length)
			return append(c);
		else if(offset == 0)
		{
			CNode temp = new CNode(c);
			temp.next = firstC;
			firstC = temp;
			length++;
			return this;
		}
		else
		{
			return stringInsert(0, c, offset, firstC, firstC.next);
		}
	}
	
	private MyStringBuilder2 stringInsert( int pos, char c, int offset, CNode curr, CNode after)
	{
		if(pos ==offset)
		{
			CNode temp = new CNode(c);
			curr.next = temp;
			temp.next = after;
			length++;
			return this;
		}
		else
			return stringInsert(pos+1, c, offset, firstC, firstC.next);
	}

	// Insert char array c into the current MyStringBuilder2 starting at index
	// index "offset" and return the current MyStringBuilder2.  If "offset" is
	// invalid, do nothing.
	public MyStringBuilder2 insert(int offset, char [] c)
	{
		if(offset<0 || offset>length)
			return this;
		else if(offset==length)
			return append(c);
		else if(offset == 0 && c.length==1)
		{
			CNode temp = new CNode(c[0]);
			temp.next = firstC;
			firstC = temp;
			length ++;
			return this;
		}
		else
			return stringInsert(0, c, offset, firstC, 0);
	}
	
	private MyStringBuilder2 stringInsert(int pos, char[]c, int offset, CNode curr, int count)
	{
		if(offset==0 && count<c.length)
		{
			CNode temp;
			if(count == 0) 
				temp = new CNode(c[c.length-1], firstC.next);
			else 
				temp = new CNode(c[c.length-count-1], firstC.next);
			CNode temp1 = firstC;
			firstC = temp;
			firstC.next = temp1;
			return stringInsert(pos+1, c, offset, null, count+1);
		}
		else
		{
			if(pos >= offset-1 && pos < offset+c.length-1)
			{
				CNode temp;
				if(count == 0) 
					temp = new CNode(c[count]);
				else 
					temp = new CNode(c[count]);

				temp.next = curr.next;
				curr.next = temp;
				return stringInsert(pos+1, c, offset, curr.next, count+1);
			} 
			else if(count == c.length)
			{ 
				length += c.length;
				return this;
			} 
			else
			{ 
				return stringInsert(pos+1, c, offset, curr.next, count);
			}
		}
	}
			

	// Return the length of the current MyStringBuilder2
	public int length()
	{
		return length;
	}

	// Delete the substring from "start" to "end" - 1 in the current
	// MyStringBuilder2, then insert String "str" into the current
	// MyStringBuilder2 starting at index "start", then return the current
	// MyStringBuilder2.  If "start" is invalid or "end" <= "start", do nothing.
	// If "end" is past the end of the MyStringBuilder2, only delete until the
	// end of the MyStringBuilder2, then insert.  This method should be done
	// as efficiently as possible.  In particular, you may NOT simply call
	// the delete() method followed by the insert() method, since that will
	// require an extra traversal of the linked list.
	public MyStringBuilder2 replace(int start, int end, String str)
	{
		if(end > length) 
			return stringReplaceEnd(start, end, str, null, null, 0, firstC, null, 0); 
		if(start>end && start<0 && end>length)
			return this;
		else if(start==0 && end ==length)
		{
			firstC = null;
			lastC = null;
			length = 0;
			makeBuilder(str, 0);
			return this;
		}
		else
			return stringReplace(start, end, str, null, null, 0, firstC, null, 0);
		
	}
	
	private MyStringBuilder2 stringReplaceEnd(int start, int end, String str, CNode begin, CNode prev, int pos, CNode node, CNode endNode, int replaceAmount)
	{
		end = length; 
		if(pos == start-1)
		{ 
			return stringReplaceEnd(start, end, str, node, prev, pos+1, node.next, null, replaceAmount);
		} 
		else if(pos >= start && replaceAmount < str.length())
		{ 
			CNode newNode = new CNode(str.charAt(pos-start));
			if(pos == start) 
				begin.next = newNode; 
			else 
				prev.next = newNode; 
			lastC = newNode;
			return stringReplaceEnd(start, end, str, begin, newNode, pos+1, null, null, ++replaceAmount);
		} 
		else if(pos >= start && replaceAmount >= str.length())
		{
			length = length + str.length()-(end-start);
			return this;
		}
		else
		{ 
			return stringReplaceEnd(start, end, str, begin, prev, pos+1, node.next, null, replaceAmount);
		}
	}

	private MyStringBuilder2 stringReplace(int start, int end, String str, CNode begin, CNode prev, int pos, CNode node, CNode endNode, int replaceAmount)
	{
		if(pos == start-1)
		{ 
			return stringReplace(start, end, str, node, prev, pos+1, node.next, endNode, replaceAmount);
		} 
		else if(pos >= start && pos < end)
		{
			CNode newNode = new CNode(str.charAt(pos-start));
			if(pos == start)
			{ 
				begin.next = newNode;
				return stringReplace(start, end, str, begin, newNode, pos+1, node.next, endNode, replaceAmount);
			} 
			else if(pos-end == -1)
			{ 
				prev.next = newNode;
				endNode = node.next;
				return stringReplace(start, end, str, begin, newNode, pos+1, node.next, endNode, replaceAmount);
			} 
			else
			{ 
				prev.next = newNode;
				return stringReplace(start, end, str, begin, newNode, pos+1, node.next, endNode, replaceAmount);
			}
		} 
		else if(pos >= end && replaceAmount+(end-start) < str.length())
		{ 
			if(pos == length-1)
			{
				CNode newNode = new CNode(str.charAt(replaceAmount+(end-start)));
				prev.next = newNode;
				return stringReplace(start, end, str, begin, newNode, pos+1, node.next, endNode, ++replaceAmount);
			} 
			else
			{
				CNode newNode = new CNode(str.charAt(replaceAmount+(end-start)));
				prev.next = newNode;
				return stringReplace(start, end, str, begin, newNode, pos+1, node.next, endNode, ++replaceAmount);
			}
		} 
		else if(pos >= end && replaceAmount+(end-start) == str.length())
		{ 
			CNode newNode = new CNode(str.charAt(replaceAmount+(end-start)-1));
			prev.next = endNode;
			newNode.next = endNode;
			length = length + str.length()-(end-start);
			return this;
		} 
		else
		{ 
			return stringReplace(start, end, str, begin, prev, pos+1, node.next, endNode, replaceAmount);
		}
	}
	// Reverse the characters in the current MyStringBuilder2 and then
	// return the current MyStringBuilder2.
	public MyStringBuilder2 reverse()
	{
		if(length == 0 || length == 1) 
			return this;
		char[] c = stringReverse(0, new char[length]);
		firstC = null;
		lastC = null;
		length = 0;
		makeBuilder(c, 0);
		return this;
	}
	
	private char[] stringReverse(int pos, char[] c)
	{
		if(pos == length-1)
		{
			c[pos] = charAt(length-pos-1);
			return c;
		} 
		else
		{
			c[pos] = charAt(length-pos-1);
			return stringReverse(pos+1, c);
		}
	}
	// Return as a String the substring of characters from index "start" to
	// index "end" - 1 within the current MyStringBuilder2
	public String substring(int start, int end)
	{
		if(end < start || start < 0 || end > length) 
			return new String(); 
		else 
			return new String(subS(start, end, new char[end-start], 0, 0, firstC));
	}

	private char[] subS(int start, int end, char[] c, int arrLoc, int pos, CNode curr)
	{
		if(pos >= start && pos < end)
		{ 
			c[arrLoc++] = curr.data;
			return subS(start, end, c, arrLoc, pos+1, curr.next);
		} 
		else if(pos == end)
			return c;
		else
			return subS(start, end, c, arrLoc, pos+1, curr.next);
	}
	// Return the entire contents of the current MyStringBuilder2 as a String
	public String toString()
	{
		if(length == 0) 
			return new String();
		else 
			return new String(makeString(new char[length], 0, firstC));
	}
	
	private char[] makeString( char[] c, int pos, CNode curr)
	{
		if(curr!=lastC)
		{
			c[pos] = curr.data;
			return makeString(c, pos+1, curr.next);
		}
		else
		{
			c[pos] = curr.data;
			return c;
		}
	}

	// Find and return the index within the current MyStringBuilder2 where
	// String str LAST matches a sequence of characters within the current
	// MyStringBuilder2.  If str does not match any sequence of characters
	// within the current MyStringBuilder2, return -1.  Think carefully about
	// what you need to do for this method before implementing it.  For some
	// help with this see the Assignment 3 specifications.
	public int lastIndexOf(String str)
	{
		MyStringBuilder2 a = new MyStringBuilder2(str);
		if(str==null)
			return -1;
		else
			return findLast(a, 0, firstC, 0, str, -1);
	}
	
	private int findLast(MyStringBuilder2 a, int pos, CNode curr, int matches, String str, int startIndex)
	{
		if(matches == str.length())
		{
			if(findLast(a,startIndex+1, curr.next, 0, str, -1)==-1)
				return startIndex;
			else
				return findLast(a,pos+1, curr.next, 0, str, -1);
		}
		else if(pos == length && matches != str.length())
			return -1;
		else if(curr.next==null)
			return -1;
		else if(curr.data == a.charAt(matches))
		{ 
			if(matches == 0) 
				startIndex = pos;
			matches++;
			return findLast(a,pos+1, curr.next, matches, str, startIndex);
		}
		else 
			return findLast(a,pos+1, curr.next,0, str, -1);
	}
	
	// Find and return an array of MyStringBuilder2, where each MyStringBuilder2
	// in the return array corresponds to a part of the match of the array of
	// patterns in the argument.  If the overall match does not succeed, return
	// null.  For much more detail on the requirements of this method, see the
	// Assignment 3 specifications.
	public MyStringBuilder2 [] regMatch(String [] pats)
	{
		return null;
	}
	
	
	// You must use this inner class exactly as specified below.  Note that
	// since it is an inner class, the MyStringBuilder2 class MAY access the
	// data and next fields directly.
	private class CNode
	{
		private char data;
		private CNode next;

		public CNode(char c)
		{
			data = c;
			next = null;
		}

		public CNode(char c, CNode n)
		{
			data = c;
			next = n;
		}
	}
}



