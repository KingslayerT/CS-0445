package MyTreePackage;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;

import MyTreePackage.BinaryTree.InorderIterator;
import StackAndQueuePackage.LinkedStack;
import StackAndQueuePackage.StackInterface;

public class ComparableBinaryTree<T extends Comparable<? super T>> extends BinaryTree<T> implements ComparableTreeInterface<T>
{
	private BinaryNode<T> root;
	protected BinaryNode<T> prev;

	   public ComparableBinaryTree()
	   {
	      root = null;
	   } // end default constructor

	   public ComparableBinaryTree(T rootData)
	   {
	      root = new BinaryNode<>(rootData);
	   } // end constructor

	   public ComparableBinaryTree(T rootData, ComparableBinaryTree<T> leftTree, 
	                                 ComparableBinaryTree<T> rightTree)
	   {
	      privateSetTree(rootData, leftTree, rightTree);
	   } // end constructor

	   public void setTree(T rootData)
	   {
	      root = new BinaryNode<>(rootData);
	   } // end setTree

	   public void setTree(T rootData, ComparableTreeInterface<T> leftTree,
	                                   ComparableTreeInterface<T> rightTree)
	   {
	      privateSetTree(rootData, (ComparableBinaryTree<T>)leftTree, 
	                               (ComparableBinaryTree<T>)rightTree);
	   } // end setTree

		private void privateSetTree(T rootData, ComparableBinaryTree<T> leftTree, 
		                                        ComparableBinaryTree<T> rightTree)
		{
	      root = new BinaryNode<>(rootData);

	      if ((leftTree != null) && !leftTree.isEmpty())
	         root.setLeftChild(leftTree.root);
	       
	      if ((rightTree != null) && !rightTree.isEmpty())
	      {
	         if (rightTree != leftTree)
	            root.setRightChild(rightTree.root);
	         else
	            root.setRightChild(rightTree.root.copy());
	      } // end if

	      if ((leftTree != null) && (leftTree != this))
	         leftTree.clear(); 
	       
	      if ((rightTree != null) && (rightTree != this))
	         rightTree.clear();
		} // end privateSetTree

	public int getHeight()
	{
		if(root==null)
			return 0;
      return root.getHeight();
	}
	
	public void setRootNode(BinaryNode<T> rootNode)
	{
      root = rootNode;
	} // end setRootNode

	protected BinaryNode<T> getRootNode()
	{
      return root;
	} // end getRootNode

	public int getNumberOfNodes()
	{
		if(root==null)
			return 0;
      return root.getNumberOfNodes();
	} 

	public T getRootData()
	{
		if (isEmpty())
			throw new EmptyTreeException();
		else
         return root.getData();
	} 

	public boolean isEmpty()
	{
      return root == null;
	} 

	public void clear()
	{
      root = null;
	} 

	public T getMax() 
	{
		return getMax1(this.getRootNode());
	}
	private T getMax1(BinaryNode<T> node)
	{
		T max = node.getData();
		T temp;
		
		if(node.hasLeftChild())
		{
			temp = getMax1(node.getLeftChild());
			if(temp.compareTo(max)>0)
				max = temp;
		}
		if(node.hasRightChild())
		{
			temp = getMax1(node.getRightChild());
			if(temp.compareTo(max)>0)
				max = temp;
		}
		return max;

	}
	
	public T getMin() 
	{
		return getMin1(this.getRootNode());
	}
	private T getMin1(BinaryNode<T> node)
	{
		T min = node.getData();
		T temp;
		
		if(node.hasLeftChild())
		{
			temp = getMin1(node.getLeftChild());
			if(temp.compareTo(min)<0)
				min = temp;
		}
		if(node.hasRightChild())
		{
			temp = getMin1(node.getRightChild());
			if(temp.compareTo(min)<0)
				min = temp;
		}
		return min;

	}

	public boolean isBST() 
	{
		prev = null;
		return isBST(root);
	}
	private boolean isBST(BinaryNode<T> node)
	{
		if(node!=null)
		{
			if(!isBST(node.getLeftChild()))
				return false;
			if(prev!=null && (node.getData().compareTo(prev.getData())<0))
				return false;
			prev = node;
			return isBST(node.getRightChild());
		}
		return true;
	}

	public int rank(T data) 
	{
		int count = 0;
		ArrayList<T> temp = new ArrayList<T>();
		rank1(this.getRootNode(), temp);
		Collections.sort(temp);
		for(int i=0; i<temp.size(); i++)
		{
			if(data.compareTo(temp.get(i))>0)
				count++;
		}
		return count;
	}
	private void rank1(BinaryNode<T> node, ArrayList<T> temp)
	{
		if(node == null)
			return ;
		temp.add(node.getData());
		rank1(node.getLeftChild(), temp);
		rank1(node.getRightChild(), temp);
	}


	public T get(int i) 
	{
		ArrayList<T> temp = new ArrayList<T>();
		rank1(this.getRootNode(), temp);
		Collections.sort(temp);
		return temp.get(i);
	}
	

}